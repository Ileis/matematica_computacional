function res = generic_polynom(x)
    res = x.^4 - 2* x.^2 + 1;
endfunction