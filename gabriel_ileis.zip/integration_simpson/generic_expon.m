function res = generic_expon(x)
    res = exp(x);
endfunction