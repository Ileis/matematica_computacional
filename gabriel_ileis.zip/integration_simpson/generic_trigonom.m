function res = generic_trigonom(x)
    res = sin(x);
endfunction